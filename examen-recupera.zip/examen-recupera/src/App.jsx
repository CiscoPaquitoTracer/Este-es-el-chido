import PokemonList from './PokemonList'
import './App.css'

function App() {

  return (
    <>     
        <PokemonList/>
    </>
  )
}

export default App
